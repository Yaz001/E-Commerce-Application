﻿using E_CommerceApplication.Data;
using E_CommerceApplication.Controllers;
using E_CommerceApplication.Models;
using E_CommerceApplication.Services;


namespace E_CommerceApplication.DTOs
{
    public class ProductCreateDto
    {
        public string Name { get; set; }
        public string Description { get; set; }
        public decimal Price { get; set; }
        public int Stock { get; set; }
        public IFormFile Image { get; set; } // This will hold the image file
    }

}
