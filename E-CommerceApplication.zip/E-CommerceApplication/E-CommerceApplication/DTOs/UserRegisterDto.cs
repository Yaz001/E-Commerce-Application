﻿using System.ComponentModel;

namespace E_CommerceApplication.DTOs
{
    public class UserRegisterDto
    {
        public string Name { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }

        [DefaultValue("User")]
        public string Role { get; set; }  // Add it for admin
    }
}
