﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

using System;
using System.Collections.Generic;
using E_CommerceApplication.Models.E_CommerceApplication.Models;

namespace E_CommerceApplication.Models
{
    public class Order
    {
        public int Id { get; set; }
        public int UserId { get; set; }

        [ForeignKey("UserId")]
        public User User { get; set; }  // Navigational property

        public DateTime OrderDate { get; set; }
        public decimal TotalPrice { get; set; }

        public List<OrderItem> OrderItems { get; set; }  // Navigational property
    }








}