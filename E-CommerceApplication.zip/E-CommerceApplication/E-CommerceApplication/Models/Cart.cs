﻿namespace E_CommerceApplication.Models
{
    public class Cart
    {
        public string UserId { get; set; } // Change to string
        public List<CartItem> Items { get; set; } = new List<CartItem>();

        public decimal TotalAmount => Items.Sum(item => item.Product.Price * item.Quantity);
    }
}
