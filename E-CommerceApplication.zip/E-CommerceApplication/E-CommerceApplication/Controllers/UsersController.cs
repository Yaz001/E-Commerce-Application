﻿using Microsoft.AspNetCore.Mvc;
using E_CommerceApplication.Models;
using E_CommerceApplication.DTOs;
using Microsoft.EntityFrameworkCore;
using E_CommerceApplication.Services;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;  // Add this for ILogger
using System.Threading.Tasks;
using BCrypt.Net;  // BCrypt for password hashing
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using Microsoft.IdentityModel.Tokens;
using System.Text;
using E_CommerceApplication.Data;

namespace E_CommerceApplication.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UsersController : ControllerBase
    {
        private readonly ECommerceDbContext _context;
        private readonly string _jwtKey;
        private readonly string _issuer;
        private readonly string _audience;
        private readonly ILogger<UsersController> _logger;  // Add ILogger

        public UsersController(ECommerceDbContext context, IConfiguration configuration, ILogger<UsersController> logger)
        {
            _context = context;

            // Access JWT settings from appsettings.json using IConfiguration
            _jwtKey = configuration["Jwt:Key"];
            _issuer = configuration["Jwt:Issuer"];
            _audience = configuration["Jwt:Audience"];

            _logger = logger;  // Assign ILogger
        }

        // Register a new user
        [HttpPost("register")]
        public async Task<IActionResult> Register(UserRegisterDto dto)
        {
            if (await _context.Users.AnyAsync(u => u.Email == dto.Email))
            {
                return BadRequest(new { Message = "A user with this email already exists." });
            }

            var role = dto.Role ?? "User";  // Default to "User" if no role is provided

            var user = new User
            {
                Name = dto.Name,
                Email = dto.Email,
                PasswordHash = BCrypt.Net.BCrypt.HashPassword(dto.Password),
                Role = role
            };

            try
            {
                _context.Users.Add(user);
                await _context.SaveChangesAsync();
                return Ok(new { Message = "User registered successfully" });
            }
            catch (DbUpdateException ex)
            {
                _logger.LogError(ex, "An error occurred while registering a new user.");
                return StatusCode(500, new { Message = "An internal server error occurred." });
            }
        }

        // Login and generate JWT token
        [HttpPost("login")]
        public async Task<IActionResult> Login(UserLoginDto dto)
        {
            var user = await _context.Users.FirstOrDefaultAsync(u => u.Email == dto.Email);
            if (user == null || !BCrypt.Net.BCrypt.Verify(dto.Password, user.PasswordHash))
            {
                return Unauthorized(new { Message = "Invalid credentials" });
            }

            // Generate JWT token including the user's role
            var token = GenerateJwtToken(user);
            return Ok(new { Token = token, Role = user.Role });  // Return the token and role in the response
        }

        // Helper method to generate JWT token
        private string GenerateJwtToken(User user)
        {
            var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_jwtKey));
            var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);

            var claims = new[]
            {
                new Claim(JwtRegisteredClaimNames.Sub, user.Id.ToString()),  // Ensure UserId is included as a string
                new Claim(JwtRegisteredClaimNames.Email, user.Email),
                new Claim(ClaimTypes.Role, user.Role)  // Include role in the JWT claims
            };

            var token = new JwtSecurityToken(
                issuer: _issuer,
                audience: _audience,
                claims: claims,
                expires: DateTime.UtcNow.AddHours(2),  // Set token expiration time
                signingCredentials: credentials
            );

            return new JwtSecurityTokenHandler().WriteToken(token);
        }

        // Test JWT Claims endpoint for debugging purposes
        [HttpGet("test-claims")]
        public IActionResult TestClaims()
        {
            // Retrieve all claims from the authenticated user's JWT
            var claims = User.Claims.Select(c => new { c.Type, c.Value }).ToList();
            return Ok(claims);
        }
    }
}
