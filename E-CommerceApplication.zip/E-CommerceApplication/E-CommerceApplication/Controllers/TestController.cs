﻿using Microsoft.AspNetCore.Mvc;

namespace E_CommerceApplication.Controllers
{
    

    [ApiController]
    [Route("api/[controller]")]
    public class TestController : ControllerBase
    {
        [HttpGet]
        public IActionResult Get()
        {
            return Ok("Test API is working!");
        }
    }

}
