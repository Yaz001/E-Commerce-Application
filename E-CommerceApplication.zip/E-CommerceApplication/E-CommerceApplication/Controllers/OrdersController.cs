﻿using E_CommerceApplication.Data;
using E_CommerceApplication.DTOs;
using E_CommerceApplication.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Security.Claims;
using System.IdentityModel.Tokens.Jwt;
using E_CommerceApplication.Models.E_CommerceApplication.Models;


namespace E_CommerceApplication.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class OrdersController : ControllerBase
    {
        private readonly ECommerceDbContext _context;

        public OrdersController(ECommerceDbContext context)
        {
            _context = context;
        }

        // Helper method to retrieve UserId from JWT and convert to int
        private int GetUserId()
        {
            // Extract the "nameidentifier" claim, which holds the UserId as a string
            var userIdString = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;

            // Ensure the claim is found and can be parsed as an integer
            if (string.IsNullOrEmpty(userIdString) || !int.TryParse(userIdString, out var userId))
            {
                throw new UnauthorizedAccessException("Invalid User ID");
            }

            return userId;  // Return the parsed UserId as an integer
        }



        [Authorize]
        [HttpPost]
        public async Task<ActionResult<Order>> CreateOrder(OrderCreateDto dto)
        {
            // Log the incoming request for debugging
            Console.WriteLine($"Creating order with TotalPrice: {dto.TotalPrice} and {dto.OrderItems.Count} items.");

            var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            if (string.IsNullOrEmpty(userId))
            {
                return BadRequest("User ID is missing.");
            }

            var order = new Order
            {
                UserId = int.Parse(userId),
                OrderDate = DateTime.Now,
                TotalPrice = dto.TotalPrice,
                OrderItems = dto.OrderItems.Select(oi => new OrderItem
                {
                    ProductId = oi.ProductId,
                    Quantity = oi.Quantity,
                    Price = oi.Price
                }).ToList()
            };

            _context.Orders.Add(order);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(GetOrder), new { id = order.Id }, order);
        }





        [HttpGet("{id}")]
        public async Task<ActionResult<Order>> GetOrder(int id)
        {
            var order = await _context.Orders
                .Include(o => o.OrderItems)
                .ThenInclude(oi => oi.Product) // This ensures Product data is included
                .FirstOrDefaultAsync(o => o.Id == id);

            if (order == null)
            {
                return NotFound();
            }

            return order;
        }





        [Authorize(Roles = "Admin")]
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Order>>> GetOrders()
        {
            var orders = await _context.Orders
                .Include(o => o.OrderItems)
                .ThenInclude(oi => oi.Product)
                .Include(o => o.User)
                .ToListAsync();

            // Map Orders to OrderDTOs
            var orderDTOs = orders.Select(order => new Order
            {
                Id = order.Id,
                UserId = order.UserId,
                User = new User
                {
                    Id = order.User.Id,
                    Name = order.User.Name,
                    Email = order.User.Email
                },
                OrderDate = order.OrderDate,
                TotalPrice = order.TotalPrice,
                OrderItems = order.OrderItems.Select(oi => new OrderItem
                {
                    Id = oi.Id,
                    OrderId = oi.OrderId, // OrderId
                    ProductId = oi.ProductId,
                    Product = new Product
                    {
                        Id = oi.Product.Id,
                        Name = oi.Product.Name,
                        Description = oi.Product.Description,
                        Price = oi.Product.Price
                    },
                    Quantity = oi.Quantity,
                    Price = oi.Price
                }).ToList()
            }).ToList();

            return Ok(orderDTOs);
        }


    }
}