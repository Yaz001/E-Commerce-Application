﻿using E_CommerceApplication.Data;
using E_CommerceApplication.DTOs;
using E_CommerceApplication.Models;
using E_CommerceApplication.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;

namespace E_CommerceApplication.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ProductsController : ControllerBase
    {
        private readonly ECommerceDbContext _context;
        private readonly ProductService _productService;
        private readonly ILogger<ProductsController> _logger;

        public ProductsController(ECommerceDbContext context, ProductService productService, ILogger<ProductsController> logger)
        {
            _context = context;
            _productService = productService;
            _logger = logger;
        }

        // GET: api/products
        [HttpGet]
        [AllowAnonymous] // Allow all users (even unauthenticated ones) to access this endpoint
        public async Task<ActionResult<IEnumerable<Product>>> GetProducts()
        {
            var products = await _productService.GetAllProductsAsync();
            return Ok(products);
        }

        // GET: api/products/{id}
        [HttpGet("{id}")]
        [AllowAnonymous] // Allow all users to access specific product details
        public async Task<ActionResult<Product>> GetProduct(int id)
        {
            var product = await _productService.GetProductByIdAsync(id);
            if (product == null)
            {
                return NotFound();
            }
            return Ok(product);
        }

        // POST: api/products
        [Authorize(Roles = "Admin")] // Only admins can add products
        [HttpPost]
        public async Task<ActionResult<Product>> AddProduct([FromForm] ProductCreateDto productDto)
        {
            if (string.IsNullOrWhiteSpace(productDto.Name))
            {
                return BadRequest("Product name is required.");
            }

            if (string.IsNullOrWhiteSpace(productDto.Description))
            {
                return BadRequest("Product description is required.");
            }

            if (productDto.Image == null || productDto.Image.Length == 0)
            {
                return BadRequest("Image is required.");
            }

            // Ensure the image directory exists
            var imagesPath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "images");
            if (!Directory.Exists(imagesPath))
            {
                Directory.CreateDirectory(imagesPath);
            }

            // Save the uploaded image to the server
            var fileName = Path.GetFileName(productDto.Image.FileName);
            var filePath = Path.Combine(imagesPath, fileName);

            using (var stream = new FileStream(filePath, FileMode.Create))
            {
                await productDto.Image.CopyToAsync(stream);
            }

            // Create the product
            var product = new Product
            {
                Name = productDto.Name,
                Description = productDto.Description,
                Price = productDto.Price,
                Stock = productDto.Stock,
                ImagePath = "/images/" + fileName  // Storing relative path for the product image
            };

            _logger.LogInformation("Adding a new product: {ProductName}", product.Name);
            var createdProduct = await _productService.AddProductAsync(product);

            return CreatedAtAction(nameof(GetProduct), new { id = createdProduct.Id }, createdProduct);
        }

        // PUT: api/products/{id}
        [Authorize(Roles = "Admin")] // Only admins can update products
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateProduct(int id, [FromForm] ProductCreateDto productDto)
        {
            var product = await _productService.GetProductByIdAsync(id);
            if (product == null)
            {
                return NotFound();
            }

            if (productDto.Image != null && productDto.Image.Length > 0)
            {
                var filePath = Path.Combine("wwwroot/images", productDto.Image.FileName);
                using (var stream = new FileStream(filePath, FileMode.Create))
                {
                    await productDto.Image.CopyToAsync(stream);
                }
                product.ImagePath = "/images/" + productDto.Image.FileName;
            }

            product.Name = productDto.Name;
            product.Description = productDto.Description;
            product.Price = productDto.Price;
            product.Stock = productDto.Stock;

            var updatedProduct = await _productService.UpdateProductAsync(product);
            if (updatedProduct == null)
            {
                return NotFound();
            }

            return NoContent();
        }

        // DELETE: api/products/{id}
        [Authorize(Roles = "Admin")] // Only admins can delete products
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteProduct(int id)
        {
            var result = await _productService.DeleteProductAsync(id);
            if (!result)
            {
                return NotFound();
            }

            return NoContent();
        }
    }
}
