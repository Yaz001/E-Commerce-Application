﻿using E_CommerceApplication.Models;
using E_CommerceApplication.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;
using System.Threading.Tasks;

namespace E_CommerceApplication.Controllers
{
    [Authorize] // Ensure only authenticated users can access these endpoints
    [Route("api/[controller]")]
    [ApiController]
    public class CartController : ControllerBase
    {
        private readonly CartService _cartService;

        public CartController(CartService cartService)
        {
            _cartService = cartService;
        }

        // Helper method to get the UserId or Username from JWT token claims
        private string GetUserId()
        {
            // Retrieves the UserId (or Username) from JWT Claims
            var userIdClaim = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            if (string.IsNullOrEmpty(userIdClaim))
            {
                throw new UnauthorizedAccessException("User ID not found in token.");
            }

            return userIdClaim; // Return as a string, since it might be a username
        }

        // GET: api/cart
        [HttpGet]
        public ActionResult<Cart> GetCart()
        {
            var userId = GetUserId(); // Retrieve UserId (or Username) from token
            var cart = _cartService.GetCart(userId);
            return Ok(cart);
        }

        // POST: api/cart/add/{productId}/{quantity}
        [HttpPost("add/{productId}/{quantity}")]
        public async Task<IActionResult> AddToCart(int productId, int quantity)
        {
            var userId = GetUserId(); // Retrieve UserId from token

            var productExists = await _cartService.AddToCart(userId, productId, quantity);
            if (!productExists)
            {
                return NotFound("Product not found.");
            }

            return Ok("Product added to cart");
        }

        // DELETE: api/cart/remove/{productId}
        [HttpDelete("remove/{productId}")]
        public IActionResult RemoveFromCart(int productId)
        {
            var userId = GetUserId(); // Retrieve UserId from token
            _cartService.RemoveFromCart(userId, productId);
            return Ok("Product removed from cart");
        }

        // DELETE: api/cart/clear
        [HttpDelete("clear")]
        public IActionResult ClearCart()
        {
            var userId = GetUserId(); // Retrieve UserId from token
            _cartService.ClearCart(userId);
            return Ok("Cart cleared");
        }
    }
}
