﻿using E_CommerceApplication.Models;
using E_CommerceApplication.Models.E_CommerceApplication.Models;
using Microsoft.EntityFrameworkCore;

namespace E_CommerceApplication.Data
{
    public class ECommerceDbContext : DbContext
    {
            public ECommerceDbContext(DbContextOptions<ECommerceDbContext> options) : base(options) { }

            public DbSet<User> Users { get; set; }
            public DbSet<Product> Products { get; set; }
            public DbSet<Order> Orders { get; set; }
            public DbSet<OrderItem> OrderItems { get; set; }

            protected override void OnModelCreating(ModelBuilder modelBuilder)
            {
            modelBuilder.Entity<Order>()
                .HasMany(o => o.OrderItems)
                .WithOne(oi => oi.Order)
                .HasForeignKey(oi => oi.OrderId);

            modelBuilder.Entity<OrderItem>()
                .HasOne(oi => oi.Product)
                .WithMany() // Or .WithMany(p => p.OrderItems) if you have a navigation property in Product
                .HasForeignKey(oi => oi.ProductId);

        }
    }
    }
