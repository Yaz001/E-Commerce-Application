﻿using E_CommerceApplication.Data;
using E_CommerceApplication.Models;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ECommerceApp.Services
{
    public class OrderService
    {
        private readonly ECommerceDbContext _context;

        public OrderService(ECommerceDbContext context)
        {
            _context = context;
        }

        // Place a new order
        public async Task<Order> PlaceOrderAsync(Order order)
        {
            _context.Orders.Add(order);
            await _context.SaveChangesAsync();
            return order;
        }

        // Get order by Id
        public async Task<Order> GetOrderByIdAsync(int id)
        {
            return await _context.Orders
                .Include(o => o.OrderItems)  // Include OrderItems
                .ThenInclude(oi => oi.Product)  // Include Product
                .Include(o => o.User)  // Include User
                .FirstOrDefaultAsync(o => o.Id == id);  // Fetch Order by Id
        }

        // Get all orders for an admin
        public async Task<List<Order>> GetAllOrdersAsync()
        {
            return await _context.Orders
                .Include(o => o.User)
                .Include(o => o.OrderItems)
                .ThenInclude(od => od.Product)
                .ToListAsync();
        }

        // Get all orders for a specific user (order history)
        public async Task<List<Order>> GetOrdersByUserIdAsync(int userId)  // Keep as int
        {
            return await _context.Orders
                .Include(o => o.OrderItems)
                .ThenInclude(od => od.Product)
                .Where(o => o.UserId == userId)  // Compare as int
                .ToListAsync();
        }


    }
}