﻿using E_CommerceApplication.Data;
using E_CommerceApplication.Models;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

public class CartService
{
    private readonly ECommerceDbContext _context;

    // Simulate in-memory cart storage (this could be persisted in a DB for production scenarios)
    private static readonly Dictionary<string, Cart> UserCarts = new Dictionary<string, Cart>(); // Use string for UserId

    public CartService(ECommerceDbContext context)
    {
        _context = context;
    }

    public Cart GetCart(string userId)
    {
        if (!UserCarts.TryGetValue(userId, out var cart))
        {
            cart = new Cart { UserId = userId }; // Update UserId to string
            UserCarts[userId] = cart;
        }
        return cart;
    }

    public async Task<bool> AddToCart(string userId, int productId, int quantity)
    {
        var cart = GetCart(userId);
        var product = await _context.Products.FindAsync(productId);

        if (product == null)
        {
            return false; // Product not found
        }

        var cartItem = cart.Items.FirstOrDefault(ci => ci.ProductId == productId);
        if (cartItem != null)
        {
            cartItem.Quantity += quantity;
        }
        else
        {
            cart.Items.Add(new CartItem
            {
                ProductId = productId,
                Quantity = quantity,
                Product = product
            });
        }
        return true; // Product added successfully
    }

    public void RemoveFromCart(string userId, int productId)
    {
        var cart = GetCart(userId);
        var cartItem = cart.Items.FirstOrDefault(ci => ci.ProductId == productId);

        if (cartItem != null)
        {
            cart.Items.Remove(cartItem);
        }
    }

    public void ClearCart(string userId)
    {
        var cart = GetCart(userId);
        cart.Items.Clear();
    }
}
