﻿const apiUrl = 'https://localhost:7117/api';  // Adjust the URL to match your API

let allProducts = []; // Store all products globally to filter easily

// Helper function to handle API responses
function handleResponse(response) {
    const contentType = response.headers.get('content-type');
    if (!response.ok) {
        if (contentType && contentType.includes('application/json')) {
            return response.json().then((error) => {
                throw new Error(error.message || 'An error occurred.');
            });
        } else {
            return response.text().then((errorText) => {
                throw new Error(errorText || 'An error occurred.');
            });
        }
    }
    return response.json();
}

// Check if user is logged in
function isLoggedIn() {
    return localStorage.getItem('token') !== null;
}

// Redirect to login if user is not authenticated
function requireLogin() {
    if (!isLoggedIn()) {
        alert('You need to be logged in.');
        window.location.href = 'login.html';
    }
}







// Fetch and display products (for index.html)
if (window.location.pathname.includes('index.html')) {
    fetch(`${apiUrl}/products`, {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json',
        },
    })
        .then(handleResponse)
        .then((products) => {
            allProducts = products; // Store all products
            displayProducts(products); // Display all products initially
        })
        .catch((error) => {
            console.error('Error fetching products:', error);
            alert('Error fetching products: ' + error.message);
        });
}

// Function to display products dynamically
function displayProducts(products) {
    const productList = document.getElementById('product-list');
    productList.innerHTML = ''; // Clear any existing content

    if (products.length === 0) {
        productList.innerHTML = '<p class="text-center">No products found.</p>';  // Handle empty product list
        return;
    }

    products.forEach((product) => {
        const productCard = `
            <div class="col-md-4 mb-4">
                <div class="card h-100">
                    <img src="${product.imagePath || 'placeholder.jpg'}" class="card-img-top" alt="${product.name}">
                    <div class="card-body text-center">
                        <h5 class="card-title">${product.name}</h5>
                        <p class="card-text">Price: $${product.price}</p>
                        <button class="btn btn-primary" onclick="showProductDetails(${product.id})">View Details</button>
                        <button class="btn btn-success" onclick="addToCart(${product.id})">Add to Cart</button>
                    </div>
                </div>
            </div>
        `;
        productList.innerHTML += productCard;
    });
}



// Function to show product details in modal
function showProductDetails(productId) {
    fetch(`${apiUrl}/products/${productId}`, {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json'
        }
    })
        .then(handleResponse)
        .then(product => {
            // Fill modal with product details
            document.getElementById('modalProductImage').src = product.imagePath || 'placeholder.jpg';
            document.getElementById('modalProductName').innerText = product.name;
            document.getElementById('modalProductDescription').innerText = product.description;
            document.getElementById('modalProductPrice').innerText = product.price.toFixed(2);

            // Set product ID for the Add to Cart button
            document.getElementById('addToCartBtn').onclick = function () {
                addToCart(product.id); // Make sure this passes the correct product ID
            };

            // Show the modal
            $('#productModal').modal('show');
        })
        .catch(error => console.error('Error fetching product details:', error));
}






// Add product to cart
function addToCart(productId) {
    requireLogin(); // Ensure the user is logged in

    const token = localStorage.getItem('token');
    fetch(`${apiUrl}/cart/add/${productId}/1`, {
        method: 'POST',
        headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json',
        },
    })
        .then(handleResponse)
        .then(() => {
            let cart = JSON.parse(localStorage.getItem('cart')) || [];

            console.log('Before adding to cart:', cart);

            const existingProduct = cart.find(item => item.productId === productId);

            if (existingProduct) {
                existingProduct.quantity++;
            } else {
                cart.push({ productId: productId, quantity: 1 });
            }

            localStorage.setItem('cart', JSON.stringify(cart));

            console.log('After adding to cart:', cart);

            alert('Product added to cart successfully!');
            updateCartCount();
            $('#productModal').modal('hide');
        })
        .catch(error => {
            console.error('Error adding product to cart:', error);
            alert('Error adding product to cart!');
        });
}

// Display Cart Items (cart.html)
if (window.location.pathname.includes('cart.html')) {
    requireLogin(); // Make sure user is logged in

    const token = localStorage.getItem('token');
    fetch(`${apiUrl}/cart`, {
        method: 'GET',
        headers: { 'Authorization': `Bearer ${token}` },
    })
        .then(handleResponse)
        .then(cart => displayCartItems(cart))
        .catch(error => console.error('Error fetching cart:', error));
}

// Function to display cart items and calculate total price
function displayCartItems(cart) {
    const cartList = document.getElementById('cart-list');
    cartList.innerHTML = ''; // Clear existing cart items

    if (!cart.items || cart.items.length === 0) {
        cartList.innerHTML = `<p>Your cart is empty.</p>`;
        return;
    }

    let totalPrice = 0;

    cart.items.forEach(item => {
        const cartItem = `
            <div class="cart-item row mb-3" data-product-id="${item.productId}">
                <div class="col-md-2">
                    <img src="${item.product.imagePath || 'placeholder.jpg'}" alt="${item.product.name}" class="img-fluid">
                </div>
                <div class="col-md-4">
                    <h5>${item.product.name}</h5>
                    <p>${item.product.description}</p>
                </div>
                <div class="col-md-2 text-center cart-item-quantity">
                    Quantity: ${item.quantity}
                </div>
                <div class="col-md-2 text-center cart-item-price">
                    Price: $${item.product.price.toFixed(2)}
                </div>
                <div class="col-md-2 text-center">
                    <button class="btn btn-danger btn-sm" onclick="removeFromCart(${item.productId})">Remove</button>
                </div>
            </div>
        `;
        cartList.innerHTML += cartItem;
        totalPrice += item.product.price * item.quantity;
    });
    updateTotalPrice(cart);  // Call the function to update the total price

    document.getElementById('total-price').innerText = totalPrice.toFixed(2);
}

// Remove item from cart
function removeFromCart(productId) {
    const token = localStorage.getItem('token');
    fetch(`${apiUrl}/cart/remove/${productId}`, {
        method: 'DELETE',
        headers: { 'Authorization': `Bearer ${token}` },
    })
        .then(response => {
            if (response.ok) {
                refreshCartDisplay();
            } else {
                console.error('Failed to remove item from cart');
            }
        })
        .catch(error => console.error('Error removing item from cart:', error));
}

// Handle Checkout (checkout.html)
if (window.location.pathname.includes('checkout.html')) {
    requireLogin();

    document.getElementById('order-form').addEventListener('submit', function (event) {
        event.preventDefault();

        const token = localStorage.getItem('token');
        fetch(`${apiUrl}/orders`, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${token}`,
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({}),
        })
            .then(handleResponse)
            .then(() => {
                alert('Order placed successfully');
                window.location.href = 'index.html';
            })
            .catch(error => console.error('Error placing order:', error));
    });
}

// Function to handle checkout (creating an order)
function checkout() {
    const token = localStorage.getItem('token');

    // Ensure the user is logged in
    if (!token) {
        alert('Please log in before placing an order.');
        window.location.href = 'login.html';
        return;
    }

    // Fetch cart items to calculate total price and prepare orderItems
    fetch(`${apiUrl}/cart`, {
        method: 'GET',
        headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json',
        }
    })
        .then(handleResponse)
        .then(cart => {
            // Check if the cart has items
            if (!cart || !cart.items || cart.items.length === 0) {
                alert('Your cart is empty! Please add products before proceeding to checkout.');
                return;
            }

            // Prepare the correct format for your order
            const totalPrice = cart.items.reduce((sum, item) => sum + (item.product.price * item.quantity), 0);
            const orderItems = cart.items.map(item => ({
                productId: item.productId,
                quantity: item.quantity,
                price: item.product.price
            }));

            // Log the order data to see if everything is correct
            console.log('Placing order with:', {
                totalPrice: totalPrice,
                orderItems: orderItems
            });

            // Send the order to the API
            fetch(`${apiUrl}/orders`, {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    totalPrice: totalPrice,
                    orderItems: orderItems
                })
            })
                .then(handleResponse)
                .then(order => {
                    alert('Order placed successfully!');
                    window.location.href = 'index.html';  // Redirect to home or another page
                })
                .catch(error => {
                    console.error('Error placing order:', error);  // Log the error
                    alert('Failed to place the order: ' + error.message);
                });
        })
        .catch(error => {
            console.error('Error fetching cart:', error);
            alert('Failed to fetch cart details: ' + error.message);
        });
}


// Checkout function with empty cart check
// Add product to cart
function addToCart(productId) {
    requireLogin(); // Ensure the user is logged in

    const token = localStorage.getItem('token');
    fetch(`${apiUrl}/cart/add/${productId}/1`, {
        method: 'POST',
        headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json',
        },
    })
        .then(response => {
            const contentType = response.headers.get('content-type');
            if (!response.ok) {
                // Handle error response
                if (contentType && contentType.includes('application/json')) {
                    return response.json().then(error => {
                        throw new Error(error.message || 'Error adding product to cart!');
                    });
                } else {
                    return response.text().then(errorText => {
                        throw new Error(errorText || 'Error adding product to cart!');
                    });
                }
            }

            // Check if the response is JSON or plain text
            if (contentType && contentType.includes('application/json')) {
                return response.json();
            } else {
                return response.text();
            }
        })
        .then(() => {
            // Notify the user the product is added successfully
            alert('Product added to cart successfully!');
            updateCartCount();
            $('#productModal').modal('hide');
        })
        .catch(error => {
            // Only show the error alert if there's an actual error
            console.error('Error adding product to cart:', error);
            alert(error.message || 'Error adding product to cart!');
        });
}


// Function to refresh cart display after an item is removed
function refreshCartDisplay() {
    const token = localStorage.getItem('token');
    fetch(`${apiUrl}/cart`, {
        method: 'GET',
        headers: { 'Authorization': `Bearer ${token}` }
    })
        .then(handleResponse)
        .then(cart => {
            displayCartItems(cart);
            updateTotalPrice(cart);
        })
        .catch(error => console.error('Error fetching cart:', error));
}


// Update the total price
function updateTotalPrice(cart) {
    let totalPrice = 0;

    if (cart.items && cart.items.length > 0) {
        totalPrice = cart.items.reduce((sum, item) => sum + (item.product.price * item.quantity), 0);
    }

    document.getElementById('total-price').innerText = totalPrice.toFixed(2);
}

// Function to update cart count in the header
function updateCartCount() {
    const token = localStorage.getItem('token');
    if (!token) return;

    fetch(`${apiUrl}/cart`, {
        method: 'GET',
        headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json',
        }
    })
        .then(handleResponse)
        .then(cart => {
            if (cart && cart.items) {
                document.getElementById('cart-count').innerText = cart.items.length;
            }
        })
        .catch((error) => {
            console.error('Error fetching cart:', error);
        });
}


// Search bar functionality
document.getElementById('productSearch').addEventListener('input', function (event) {
    const query = event.target.value.toLowerCase();
    const filteredProducts = allProducts.filter(product =>
        product.name.toLowerCase().includes(query) ||
        product.description.toLowerCase().includes(query)
    );
    displayProducts(filteredProducts);
});

// Helper function to extract userId from the token (this is an example, adjust according to your token structure)
function getUserIdFromToken(token) {
    const payload = JSON.parse(atob(token.split('.')[1]));
    return payload.userId;
}

// Call updateCartCount when the page loads to ensure the correct count is displayed
window.onload = function () {
    updateCartCount();
};
